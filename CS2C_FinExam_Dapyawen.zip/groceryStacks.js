// Create an empty array to store grocery items
let groceryStack = [];

// Peek function to check if the stack is empty or not
function peek() {
  if (groceryStack.length === 0) {
    console.log("The stack is empty.");
    return null;
  } else {
    console.log("Current top of the stack: " + groceryStack[groceryStack.length - 1]);
    return groceryStack[groceryStack.length - 1];
  }
}

// Push function to add an item to the stack
function push(item) {
  groceryStack.push(item); // Add the item to the top of the stack
  console.log("Item added: " + item);
  peek(); // Check the top of the stack
  console.log("Updated stack: ", groceryStack);
}

// Pop function to remove the last added item from the stack
function pop() {
  if (groceryStack.length > 0) {
    const removedItem = groceryStack.pop(); // Remove the last item
    console.log("Item removed: " + removedItem);
    peek(); // Check the top of the stack
    console.log("Updated stack: ", groceryStack);
  } else {
    console.log("The stack is already empty. No item to pop.");
  }
}

// Function to prompt the user for grocery items and manage the stack
function manageGroceryStack() {
  for (let i = 0; i < 5; i++) {
    let item = prompt(`Enter grocery item #${i + 1}:`);
    push(item); // Push the entered item to the stack
  }

  // Now perform a few pop operations
  let popCount = 2; // For example, pop 2 items
  for (let i = 0; i < popCount; i++) {
    pop(); // Pop an item from the stack
  }
}

// Run the grocery stack manager
manageGroceryStack();
