// Declare variables with prompt to get the user input 
let word1 = prompt("Enter the first word: ");  // Example: "RACECAR"
let word2 = prompt("Enter the second word: ");  // Example: "RECORDER"

// Reverse the strings
let reversedWord1 = word1.split('').reverse().join('');
let reversedWord2 = word2.split('').reverse().join('');

// Log the original and reversed strings to the console
console.log("Original word 1: " + word1);
console.log("Reversed word 1: " + reversedWord1);
console.log("Original word 2: " + word2);
console.log("Reversed word 2: " + reversedWord2);

// Check if the original string is the same as the reversed string
console.log("Is the first word a palindrome? " + (word1 === reversedWord1));
console.log("Is the second word a palindrome? " + (word2 === reversedWord2));

