// Define the Node class
class Node {
  constructor(value) {
    this.value = value; // Store the value
    this.next = null; // Point to the next node (initially null)
  }
}

// Define the LinkedList class
class LinkedList {
  constructor() {
    this.head = null; // The head of the list is initially null
    this.size = 0; 
  }

  // Append method to add new nodes to the linked list
  append(value) {
    const newNode = new Node(value); // Create a new node with the given value
    if (this.head === null) {
      // If the list is empty, make the new node the head
      this.head = newNode;
    } else {
      // If the list is not empty, find the last node and append the new node
      let current = this.head;
      while (current.next !== null) {
        current = current.next;
      }
      current.next = newNode;
    }
    this.size++; // Increase the size of the list
    this.print(); // Print the list after appending the new node
  }

  // Print method to output the entire list
  print() {
    let current = this.head;
    let listString = '';
    while (current !== null) {
      listString += current.value + ' -> ';
      current = current.next;
    }
    // Print the list (remove the last " -> " for clarity)
    console.log(listString.slice(0, -4)); 
  }
}

// Example usage of the LinkedList class
const list = new LinkedList();

// Append items to the list
list.append("Data Structures-Array");
list.append("Variable Type-Integer");
list.append("Sorting Algorithm-Bubble Sort");
