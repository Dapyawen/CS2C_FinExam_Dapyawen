// Create an empty array to hold the numbers
let numbers = [];

// Function to populate the array with user input
function populateArray() {
  for (let i = 0; i < 10; i++) {
    let num = prompt(`Enter number ${i + 1}:`);
    numbers.push(parseInt(num));  // Convert the input to an integer and add it to the array
  }
  console.log("Initial Array:", numbers);
}

// Bubble Sort Algorithm Implementation
function bubbleSort(arr) {
  let n = arr.length;
  let swapped;

  for (let i = 0; i < n - 1; i++) {
    swapped = false;
    console.log(`Pass ${i + 1}:`);

    // Compare adjacent elements and swap if they are in the wrong order
    for (let j = 0; j < n - 1 - i; j++) {
      console.log(`Comparing ${arr[j]} and ${arr[j + 1]}`);
      if (arr[j] > arr[j + 1]) {
        // Swap the elements
        let temp = arr[j];
        arr[j] = arr[j + 1];
        arr[j + 1] = temp;
        swapped = true;
        console.log(`Swapped: ${arr[j]} and ${arr[j + 1]}`);
      }
    }

    // If no two elements were swapped in the inner loop, the array is sorted
    if (!swapped) break;

    console.log("Array after pass:", arr);
  }

  return arr;
}

// Function to manage the process
function sortNumbers() {
  populateArray(); // Populate the array with user inputs
  console.log("Sorting process:");
  let sortedArray = bubbleSort(numbers); // Perform the Bubble Sort
  console.log("Sorted Array:", sortedArray); // Log the sorted array
}

// Run the sorting function
sortNumbers();
