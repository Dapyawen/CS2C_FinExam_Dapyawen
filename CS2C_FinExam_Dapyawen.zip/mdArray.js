// Create two arrays using prompt() to get user input
let names = prompt("Enter names separated by commas (e.g., Genevieve, Juan, Luna, Gabriel, Elise)").split(",");
let ages = prompt("Enter ages separated by commas (e.g., 24, 65, 21, 5, 9)").split(",").map(Number);

// Initialize an empty array to store the restructured multi-dimensional array
let restructuredArray = [];

// Restructure the array by combining names and ages
for (let i = 0; i < names.length; i++) {
    restructuredArray.push([names[i], ages[i]]);
}

// Log the restructured multi-dimensional array
console.log("Restructured Array (Name, Age):");
restructuredArray.forEach(person => {
    console.log(person);  // Logs each sub-array [name, age]
});
